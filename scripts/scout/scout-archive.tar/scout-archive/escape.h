int escapeBehaviour(float *, long, float *, float *);
