int  seekBehaviour(float *, long, float *, float *);
